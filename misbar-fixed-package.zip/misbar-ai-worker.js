/**
 * Misbar AI Gateway — Cloudflare Worker example.
 * Set secret: wrangler secret put ANTHROPIC_API_KEY
 * Optional env var: ALLOWED_ORIGIN=https://YOUR-USER.github.io
 */
export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = env.ALLOWED_ORIGIN || '*';
    const cors = {
      'Access-Control-Allow-Origin': allowed === '*' ? '*' : (origin === allowed ? origin : allowed),
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Vary': 'Origin',
    };

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers: cors });
    if (!env.ANTHROPIC_API_KEY) return Response.json({ error: 'Server AI key is not configured.' }, { status: 500, headers: cors });

    let body;
    try { body = await request.json(); }
    catch { return Response.json({ error: 'Invalid JSON body.' }, { status: 400, headers: cors }); }

    const userText = String(body?.userText || '').trim().slice(0, 3000);
    const systemText = String(body?.systemText || '').trim().slice(0, 6000);
    if (!userText || !systemText) return Response.json({ error: 'Missing prompt.' }, { status: 400, headers: cors });

    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1200,
        system: systemText,
        messages: [{ role: 'user', content: userText }],
      }),
    });

    let data;
    try { data = await upstream.json(); }
    catch { return Response.json({ error: 'Invalid upstream response.' }, { status: 502, headers: cors }); }

    if (!upstream.ok) {
      return Response.json({ error: data?.error?.message || `AI provider error (${upstream.status})` }, { status: upstream.status, headers: cors });
    }

    const text = (data.content || []).filter(x => x?.type === 'text').map(x => x.text).join('\n').trim();
    if (!text) return Response.json({ error: 'AI returned no text.' }, { status: 502, headers: cors });
    return Response.json({ text }, { headers: { ...cors, 'Cache-Control': 'no-store' } });
  },
};
